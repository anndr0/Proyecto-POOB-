package ICPC;
public class __SHELL205 extends bluej.runtime.Shell {
public static void run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("C:\\Users\\pc\\OneDrive - ESCUELA COLOMBIANA DE INGENIERIA JULIO GARAVITO\\U N I V E R S I D A D\\Semestre 6\\POOB\\PRIMER CORTE\\Proyecto-POOB-\\ICPC\\ICPC");
final ICPC.Iceepeecee iceepeec1 = (ICPC.Iceepeecee)__bluej_runtime_scope.get("iceepeec1");


java.lang.String __bluej_param0 = "lightGreen";
int[][] __bluej_param1 = {{45,60},{55,55},{60,60},{55,65}};
iceepeec1.addIsland(__bluej_param0,__bluej_param1);

}}
