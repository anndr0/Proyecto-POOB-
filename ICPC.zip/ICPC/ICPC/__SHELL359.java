package ICPC;
public class __SHELL359 extends bluej.runtime.Shell {
public static java.lang.Object run() throws Throwable {

int[][][] __bluej_param0 = { {{90, 80}, {120, 70}, {105, 90}, {85, 90}},    {{150, 100}, {170, 100}, {160, 120}},    {{140, 150}, {160, 150}, {160, 170}, {140, 170}},    {{200, 80}, {220, 80}, {220, 100}, {200, 100}}};
int[][][] __bluej_param1 = {   {{80, 30, 90}, {170, 75, 50}},    {{135, 50, 175}, {175, 130, 195}},    {{140, 125, 185}, {215, 165, 205}}};
try {
return makeObj(ICPC.IceepeeceeContest.solveIceepeecee(__bluej_param0,__bluej_param1)
);}
finally {
}
}}
