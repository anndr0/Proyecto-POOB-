package ICPC;
public class __SHELL98 extends bluej.runtime.Shell {
public static void run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("C:\\Users\\pc\\OneDrive - ESCUELA COLOMBIANA DE INGENIERIA JULIO GARAVITO\\U N I V E R S I D A D\\Semestre 6\\POOB\\PRIMER CORTE\\Proyecto-POOB-\\ICPC\\ICPC");
final ICPC.Iceepeecee iceepeec1 = (ICPC.Iceepeecee)__bluej_runtime_scope.get("iceepeec1");


java.lang.String __bluej_param0 = "surprising";
java.lang.String __bluej_param1 = "lightLilac";
int[][] __bluej_param2 = {{40,20},{60,10},{75,20},{60,30}};
iceepeec1.addIsland(__bluej_param0,__bluej_param1,__bluej_param2);

}}
