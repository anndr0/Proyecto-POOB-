package ICPC;
public class __SHELL330 extends bluej.runtime.Shell {
public static java.lang.Object run() throws Throwable {

return new java.lang.Object() { ICPC.Iceepeecee __bluej__result__;
{ int[][][] __bluej_param0 = {    {{20, 30}, {50, 50}, {10, 50}},    {{40, 20}, {60, 10}, {75, 20}, {60, 30}},    {{45, 60}, {55, 55}, {60, 60}, {55, 65}},    {{90, 80}, {120, 70}, {105, 90}, {85, 90}},    {{150, 100}, {170, 100}, {160, 120}},    {{140, 150}, {160, 150}, {160, 170}, {140, 170}},    {{200, 80}, {220, 80}, {220, 100}, {200, 100}}};
int[][][] __bluej_param1 = {    {{0, 30, 20}, {78, 70, 5}},    {{55, 0, 20}, {70, 60, 10}},    {{80, 30, 90}, {170, 75, 50}},    {{135, 50, 175}, {175, 130, 195}},    {{140, 125, 185}, {215, 165, 205}}};
try {
__bluej__result__=(new ICPC.Iceepeecee(__bluej_param0,__bluej_param1)
);}
finally {
}} };
}}
