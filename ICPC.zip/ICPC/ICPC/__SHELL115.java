package ICPC;
public class __SHELL115 extends bluej.runtime.Shell {
public static java.lang.Object run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("C:\\Users\\pc\\OneDrive - ESCUELA COLOMBIANA DE INGENIERIA JULIO GARAVITO\\U N I V E R S I D A D\\Semestre 6\\POOB\\PRIMER CORTE\\Proyecto-POOB-\\ICPC\\ICPC");
final ICPC.Iceepeecee iceepeec1 = (ICPC.Iceepeecee)__bluej_runtime_scope.get("iceepeec1");


java.lang.String __bluej_param0 = "lightLilac";
try {
return makeObj(iceepeec1.islandLocation(__bluej_param0)
);}
finally {
}
}}
