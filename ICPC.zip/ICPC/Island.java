import java.util.HashMap;
import java.util.Map;
import java.awt.*;
import java.util.Set;
import java.util.HashSet;

/**
 * The Island class represents an island with a polygon shape on the canvas.
 * It allows to create and manipulate islands.
 * Islands can be made visible or invisible, and their locations can be queried.
 * 
 * @author Laura Natalia Rojas and Ana Maria Duran
 * @version 23/09/23
 */
public class Island {
    private static HashMap<String, Polygon> islands = new HashMap<>();
    private boolean isVisible;
    private int[][] vertexArray;
    private String color;
    private boolean operationSuccess;
    private static Set<String> usedColors = new HashSet<>();

    /**
     * Constructs an Island object with the specified vertex array and color.
     * The island is created as a polygon with the given vertices and color.
     *  Los nombres de color válidos son:
     
     * @param vertexArray An array of vertices representing the island's shape.
     * @param color       The color of the island.
     */
    public Island(String color, int[][] vertexArray) {
        if (usedColors.contains(color)) {
            throw new IllegalArgumentException("El color " + color + " ya se ha utilizado para otra isla.");
        }
        
        this.color = color;
        usedColors.add(color);
        Polygon polygon = new Polygon(color, vertexArray); // Create a Polygon with the specified color
        islands.put(color, polygon); // Use the color as the key in the map
        polygon.makeVisible();
        polygon.draw();
        operationSuccess = true;
    }

    /**
     * Get the color of the island.
     * 
     * @return The color of the island.
     */
    public String getColor() {
        return this.color;
    }
    
    /**
     * Make the island with the specified color visible.
     * 
     * @param color The color of the island to make visible.
     */
    public void makeIslandVisible(String color) {
        Polygon polygon = islands.get(color);
        if (polygon != null) {
            polygon.makeVisible(); // Make the polygon of the specified island visible
        }
    }

    /**
     * Make the island with the specified color invisible.
     * 
     * @param color The color of the island to make invisible.
     */
    public void makeIslandInvisible(String color) {
        Polygon polygon = islands.get(color);
        if (polygon != null) {
            polygon.makeInvisible(); // Make the polygon of the specified island invisible
        }
    }   
    
    /**
     * Delete the island with the specified color.
     * 
     * @param color The color of the island to delete.
     */
    public void delIsland(String color) {
        Polygon polygon = islands.get(color);
        if (polygon != null) {
            polygon.makeInvisible();
            islands.remove(color);
            operationSuccess = true; // Indicar que la eliminación fue exitosa
        } else {
            operationSuccess = false; // Indicar que la eliminación no fue exitosa
        }
    }
    
    /**
     * Get the location of the island with the specified color.
     * 
     * @param color The color of the island to query.
     * @return A string representing the location of the island.
     */
    public String locationIsland(String color) {
        Polygon polygon = islands.get(color);
        if (polygon != null) {
            int[][] coordinates = polygon.getVertexArray();
            StringBuilder location = new StringBuilder("Location of Island (Color: " + color + "): {");
            
            for (int i = 0; i < coordinates.length; i++) {
                location.append("{").append(coordinates[i][0]).append(", ").append(coordinates[i][1]).append("}");
                if (i < coordinates.length - 1) {
                    location.append(", ");
                }
            }
            
            location.append("}");
            return location.toString();
        } else {
            return "Island not found"; // Return a message if the island does not exist
        }
    }
    
    /**
     * Get the vertex array of the island.
     * 
     * @return An array of vertices representing the island's shape.
     */
    public int[][] getVertexArray() {
        return vertexArray;
    }
    
    /**
     * Muestra las islas almacenadas en el HashMap, incluyendo su color y vértices.
     */
    public static void mostrarIslas() {
        System.out.println("Islas almacenadas en el HashMap:");
        for (Map.Entry<String, Polygon> entry : islands.entrySet()) {
            String color = entry.getKey();
            Polygon polygon = entry.getValue();
            System.out.println("Color: " + color);
            System.out.println("Vertices: " + polygon.getVertexArray());
            System.out.println("------------------------");
        }
    }
    
    
    /**
     * Verifica si la última operación en la simulación fue exitosa.
     *
     * @return true si la última operación fue exitosa, false si no lo fue.
     */
    public boolean ok() {
        // Verifica si la última operación fue exitosa.
        return operationSuccess;
    }


}
