
public class __SHELL4 extends bluej.runtime.Shell {
public static void run() throws Throwable {

int[][][] __bluej_param0 = {{{20,30},{50,50},{10,50}},{{40,20},{60,10},{75,20},{60,30}},{{45,60},{55,55},{60,60},{55,65}}};
int[][][] __bluej_param1 = {{{0,30,20},{78,70,5}},{{55,0,20},{70,60,10}}};
IceepeeceeContest.simulate(__bluej_param0,__bluej_param1);

}}
