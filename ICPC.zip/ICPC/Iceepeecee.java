import java.util.List;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * The Iceepeecee class represents an environment for managing islands, flights, and photographs.
 * It allows users to add, delete, and interact with these elements within a graphical canvas.
 * 
 * @author Ana María Durán And Laura Natalia Rojas
 * @version 23/03/23
 */
public class Iceepeecee {
    private int length;
    private int width;
    private boolean isVisible;
    private HashMap<String, Island> islands;
    private HashMap<String, Flight> flights;
    private Canvas canvas;
    private boolean operationSuccess;
    private List<Photograph> photographs;
    
    /**
     * Constructs an Iceepeecee object with the specified canvas dimensions.
     * 
     * @param length The length of the canvas.
     * @param width  The width of the canvas.
     */
    public Iceepeecee(int length, int width) {
        this.length = length; // Inicializa la longitud del canvas
        this.width = width;   // Inicializa el ancho del canvas
        canvas = Canvas.getCanvas(length, width);
        canvas.setVisible(true);
        islands = new HashMap<>();
        flights = new HashMap<>();
        isVisible = false;
    }
    
    /**
     * Add an island to Iceepeecee.
     * Do not repeat the color pls( •ㅅ•)
     * -----
     *  Valid colors are: 
     *  "red", "green", "blue", "yellow", "purple", "cyan", "pink", "orange", 
     *  "brown", "gray", "magenta", "white", "lightBlue", "lime", "gold", "teal", "violet", "coral", "lavender", 
     *  "olive", "maroon", "turquoise", "navyBlue", "bistre", "burgundy", "crimson", "lightCyan", "cobalt", 
     *  "fuchsia", "garnet", "lightGray", "darkGray", "indigo", "lightLilac", "lightLime", "lightMagenta", 
     *  "lightBrown", "darkBrown", "lightOrange", "darkOrange", "lightGold", "darkGold", "silver", "lightPink", 
     *  "darkPink", "darkTurquoise", "lightGreen", "darkGreen", "lightViolet", "darkViolet"
     *  ----
     * @param color       The color of the island.
     * @param vertexArray The vertices of the island.
     */
    public void addIsland(String color, int[][] vertexArray) {
        if (!islands.containsKey(color)) {
            Island island = new Island(color, vertexArray);
            islands.put(color, island);
            operationSuccess = true; // Indicar que la adición fue exitos
        } else {
            operationSuccess = false; // Indicar que la adición no fue exitosa
        }
    }
    
    /**
     * Get an island by its color.
     * 
     * @param color The color of the island to retrieve.
     * @return The Island object with the specified color, or null if not found.
     */
    public Island getIsland(String color) {
        return islands.get(color);
    }

    /**
     * Delete an island from Iceepeecee.
     * ╰(◣﹏◢)╯
     * @param color The color of the island to delete.
     */
    public void deleteIsland(String color) {
        Island island = islands.get(color);
        if (island != null) {
            islands.remove(color);
            island.delIsland(color); // Calls the method to delete the island in Island
            operationSuccess = true;
        } else{
            operationSuccess = false;
        }
    }
    
        /**
     * Make the island with the specified color visible.
     * 
     * @param color The color of the island to make visible.
     */
    public void makeIslandVisible(String color) {
        Island island = islands.get(color);
        if (island != null) {
            island.makeIslandVisible(color); // Make the polygon of the specified island visible
        }
    }

    /**
     * Make the island with the specified color invisible.
     * 
     * @param color The color of the island to make invisible.
     */
    public void makeIslandInvisible(String color) {
        Island island = islands.get(color);
        if (island != null) {
            island.makeIslandInvisible(color); // Make the polygon of the specified island invisible
        }
    } 
    
    
    /**
     * Get the location of an island by color.
     * 
     * @param island The color of the island to query.
     * @return A string representing the location of the island.
     */
    public String islandLocation(String island) {
        Island islandObj = islands.get(island);
        if (islandObj != null) {
            operationSuccess = true;
            return islandObj.locationIsland(island);
        } else {
            operationSuccess = false;
            return "Island not found"; // Returns a message if the island does not exist
        }
    }
    
    /**
     * Add a flight to Iceepeecee.
     * Do not repeat the color pls( •ㅅ•)
     *  -----
     *  Valid colors are: 
     *  "red", "green", "blue", "yellow", "purple", "cyan", "pink", "orange", 
     *  "brown", "gray", "magenta", "white", "lightBlue", "lime", "gold", "teal", "violet", "coral", "lavender", 
     *  "olive", "maroon", "turquoise", "navyBlue", "bistre", "burgundy", "crimson", "lightCyan", "cobalt", 
     *  "fuchsia", "garnet", "lightGray", "darkGray", "indigo", "lightLilac", "lightLime", "lightMagenta", 
     *  "lightBrown", "darkBrown", "lightOrange", "darkOrange", "lightGold", "darkGold", "silver", "lightPink", 
     *  "darkPink", "darkTurquoise", "lightGreen", "darkGreen", "lightViolet", "darkViolet"
     *  ----
     * @param color The color of the flight.
     * @param from  The starting coordinates [x1, y1, z1].
     * @param to    The ending coordinates [x2, y2, z2].
     */
    public void addFlight(String color, int[] from, int[] to) {
        if (!flights.containsKey(color)) {
            Flight flight = new Flight(color, from, to);
            flights.put(color, flight);
            operationSuccess = true; // Indicar que la adición fue exitosa
        } else{
            operationSuccess = false; // Indicar que la adición no fue exitosa
        }
    }
    
    /**
     * Delete a flight from Iceepeecee.
     * ╰(◣﹏◢)╯ 
     * @param color The color of the flight to delete.
     */
    public void deleteFlight(String color) {
        Flight flight = flights.get(color);
        if (flight != null) {
            // Eliminar las fotografías asociadas al vuelo
            List<Photograph> photographs = flight.getPhotographs();
            for (Photograph photograph : photographs) {
                photograph.makeInvisible(); // Hacer invisible la fotografía
            }
            photographs.clear(); // Borrar todas las fotografías de la lista
            flights.remove(color);
            flight.deleteFlight(color); // Calls the method to delete the flight in Flight
            operationSuccess = true;
        } else {
            operationSuccess = false;
        }
    }
    
    /**
     * Get the location of a flight by color.
     * 
     * @param flight The color of the flight to query.
     * @return A string representing the location of the flight.
     */
    public String flightLocation(String flight) {
        Flight flightObj = flights.get(flight);
        if (flightObj != null) {
            operationSuccess = true; // Indicate that the flight location retrieval was successful
            return flightObj.locationFlight(flight);
        } else {
            operationSuccess = false; // Indicate that the flight location retrieval was not successful
            return "Flight not found"; // Returns a message if the flight does not exist
        }
    }
    
        /**
     * Make the flight visible by its color.
     * 
     * @param color The color of the flight to make visible.
     */
    public void makeFlightVisible(String color) {
        Flight flight = flights.get(color);
        if (flight != null) {
            flight.isVisible = true;
            List<Photograph> photographs = flight.getPhotographs();
            for (Photograph photograph : photographs) {
                photograph.makeVisible(); // Hacer invisible la fotografía
            }
            flight.draw();
        }
    }
    
    /**
     * Make the flight invisible by its color.
     * 
     * @param color The color of the flight to make invisible.
     */
    public void makeFlightInvisible(String color) {
        Flight flight = flights.get(color);
        if (flight != null) {
            flight.isVisible = false;
            Canvas canvas = Canvas.getCanvas();
            List<Photograph> photographs = flight.getPhotographs();
            for (Photograph photograph : photographs) {
                photograph.makeInvisible(); // Hacer invisible la fotografía
            }
            
            canvas.erase(flight);
        }
    }
    
    /**
     * Capture a photograph from a specific flight at the given angle (theta).
     * 
     * @param flightColor The color of the flight to capture a photograph from.
     * @param theta       The angle (in radians) at which the photograph is taken.
     */
    public void photograph(String flightColor, double theta) {
        Flight flight = flights.get(flightColor); // Get the flight by its color
        if (flight != null ) {
            Photograph photograph = new Photograph(flightColor, theta); // Create a photograph with the flight and theta
            operationSuccess = true;
        } else {
            System.out.println("Flight not found"); // Display a message if the flight is not found
            operationSuccess = false;
        }
    }
    
    /**
     * Capture photographs from all flights in Iceepeecee at the given angle (theta).
     * 
     * @param theta The angle (in radians) at which the photographs are taken.
     */
    public void photograph(double theta) {
        operationSuccess = true;
        for (Flight flight : flights.values()) {
            String color = flight.getColor(); // Get the color of the flight
            flight.camera(color, theta); // Calls the camera method of each visible flight with the color and theta
            if (!flight.ok()) {
                operationSuccess = false;
            }
        }
    }
    
    /**
     * Make all elements in Iceepeecee visible, including flights, islands, and photographs.
     */
    public void makeVisible() {
        // Make all flights visible
        for (Flight flight : flights.values()) {
            String color = flight.getColor();
            flight.makeFlightVisible(color);
            if (!flight.ok()) {
                operationSuccess = false;
            }
        }

        // Make all islands visible
        for (Island island : islands.values()) {
            String color = island.getColor();
            island.makeIslandVisible(color);
            if (!island.ok()) {
                operationSuccess = false;
            }
        }
        
        // Make all photographs visible
        for (Flight flight : flights.values()) {
            List<Photograph> photographs = flight.getPhotographs();
            for (Photograph photograph : photographs) {
                photograph.makeVisible(); // Hace invisible cada fotografía asociada a un vuelo
            if (!photograph.ok()) {
                operationSuccess = false;
            }
            }
        }
    }

    /**
     * Make all elements in Iceepeecee invisible, including flights, islands, and photographs.
     */
    public void makeInvisible() {
        // Make all flights invisible
        for (Flight flight : flights.values()) {
            String color = flight.getColor();
            flight.makeFlightInvisible(color);
            if (!flight.ok()) {
                operationSuccess = false;
            }
        }
        // Make all islands invisible
        for (Island island : islands.values()) {
            String color = island.getColor();
            island.makeIslandInvisible(color);
            if (!island.ok()) {
                operationSuccess = false;
            }
        }
        // Make all photographs invisible
        for (Flight flight : flights.values()) {
            List<Photograph> photographs = flight.getPhotographs();
            for (Photograph photograph : photographs) {
                photograph.makeInvisible(); // Hace invisible cada fotografía asociada a un vuelo
                if (!photograph.ok()) {
                    operationSuccess = false;
                }
            }
        }
    }
    
    public double flightCamera(String color) {
        Flight flight = flights.get(color); // Obtén el vuelo por su color
        if (flight != null) {
            List<Photograph> photographs = flight.getPhotographs();
            if (!photographs.isEmpty()) {
                // Obtiene la última fotografía de la lista
                Photograph lastPhotograph = photographs.get(photographs.size() - 1);
                // Usa el método getTheta para obtener el ángulo de la última fotografía
                return lastPhotograph.getTheta();
            } else {
                System.out.println("No photographs taken for this flight.");
            }
        } else {
            System.out.println("Flight not found");
        }
        // Si no se encuentra el vuelo o no hay fotografías, retorna un valor por defecto (puedes cambiarlo según tu necesidad)
        return 0.0;
    }
    
    /**
     * Muestra la información de todas las islas almacenadas en Iceepeecee.
     */
    public void showAllIslands() {
        System.out.println("Islas almacenadas en Iceepeecee:");
        for (Island island : islands.values()) {
            String color = island.getColor();
            System.out.println("Color: " + color);
            System.out.println(island.locationIsland(color)); // Utiliza el método locationIsland para mostrar la ubicación
            System.out.println("------------------------");
        }
    }
    
    /**
     * Muestra la información de todos los vuelos almacenados en Iceepeecee.
     */
    public void showAllFlights() {
        System.out.println("Vuelos almacenados en Iceepeecee:");
        for (Flight flight : flights.values()) {
            String color = flight.getColor();
            System.out.println("Color: " + color);
            System.out.println(flight.locationFlight(color)); // Utiliza el método locationIsland para mostrar la ubicación
            System.out.println("------------------------");
        }
    }
    
    /**
     * Verifica si la última operación en la simulación fue exitosa.
     *
     * @return true si la última operación fue exitosa, false si no lo fue.
     */
    public boolean ok() {
        return operationSuccess;
    }
    
    /**
     * Finaliza la simulación y cierra el lienzo gráfico.
     */
    public void finish() {
        Canvas canvas = Canvas.getCanvas(); // Obtiene la instancia del lienzo gráfico
        canvas.setVisible(false); // Oculta el lienzo gráfico
        System.exit(0); // Cierra la aplicación
        System.out.println("Simulación finalizada.");
    }

}
