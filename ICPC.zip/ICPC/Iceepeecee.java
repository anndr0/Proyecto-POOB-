import java.util.List;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * The Iceepeecee class represents an environment for managing islands, flights, and photographs.
 * It allows users to add, delete, and interact with these elements within a graphical canvas.
 * 
 * @author Ana María Durán And Laura Natalia Rojas
 * @version 23/03/23
 */
public class Iceepeecee {
    private int length;
    private int width;
    private boolean isVisible;
    private HashMap<String, Island> islands;
    private HashMap<String, Flight> flights;
    private Canvas canvas;
    
    /**
     * Constructs an Iceepeecee object with the specified canvas dimensions.
     * 
     * @param length The length of the canvas.
     * @param width  The width of the canvas.
     */
    public Iceepeecee(int length, int width) {
        this.length = length; // Inicializa la longitud del canvas
        this.width = width;   // Inicializa el ancho del canvas
        canvas = Canvas.getCanvas(length, width);
        canvas.setVisible(true);
        islands = new HashMap<>();
        flights = new HashMap<>();
        isVisible = false;
    }
    
    /**
     * Add an island to Iceepeecee.
     * 
     * @param color       The color of the island.
     * @param vertexArray The vertices of the island.
     */
    public void addIsland(String color, int[][] vertexArray) {
        Island island = new Island(color, vertexArray);
        islands.put(color, island);
    }
        
    /**
     * Get an island by its color.
     * 
     * @param color The color of the island to retrieve.
     * @return The Island object with the specified color, or null if not found.
     */
    public Island getIsland(String color) {
        return islands.get(color);
    }

    /**
     * Delete an island from Iceepeecee.
     * 
     * @param color The color of the island to delete.
     */
    public void deleteIsland(String color) {
        Island island = islands.get(color);
        if (island != null) {
            islands.remove(color);
            island.delIsland(color); // Calls the method to delete the island in Island
        }
    }
    
    /**
     * Get the location of an island by color.
     * 
     * @param island The color of the island to query.
     * @return A string representing the location of the island.
     */
    public String islandLocation(String island) {
        Island islandObj = islands.get(island);
        if (islandObj != null) {
            return islandObj.locationIsland(island);
        } else {
            return "Island not found"; // Returns a message if the island does not exist
        }
    }
    
    /**
     * Add a flight to Iceepeecee.
     * 
     * @param color The color of the flight.
     * @param from  The starting coordinates [x1, y1, z1].
     * @param to    The ending coordinates [x2, y2, z2].
     */
    public void addFlight(String color, int[] from, int[] to) {
        Flight flight = new Flight(color, from, to);
        flights.put(color, flight);
    }
    
    /**
     * Delete a flight from Iceepeecee.
     * 
     * @param color The color of the flight to delete.
     */
    public void deleteFlight(String color) {
        Flight flight = flights.get(color);
        if (flight != null) {
            flights.remove(color);
            flight.deleteFlight(color); // Calls the method to delete the flight in Flight
        }
    }
    
    /**
     * Get the location of a flight by color.
     * 
     * @param flight The color of the flight to query.
     * @return A string representing the location of the flight.
     */
    public String flightLocation(String flight) {
        Flight flightObj = flights.get(flight);
        if (flightObj != null) {
            return flightObj.locationFlight(flight);
        } else {
            return "Flight not found"; // Returns a message if the flight does not exist
        }
    }
    
    /**
     * Capture a photograph from a specific flight at the given angle (theta).
     * 
     * @param flightColor The color of the flight to capture a photograph from.
     * @param theta       The angle (in radians) at which the photograph is taken.
     */
    public void photograph(String flightColor, double theta) {
        Flight flight = flights.get(flightColor); // Get the flight by its color
        if (flight != null) {
            Photograph photograph = new Photograph(flightColor, theta); // Create a photograph with the flight and theta
        } else {
            System.out.println("Flight not found"); // Display a message if the flight is not found
        }
    }
    
    /**
     * Capture photographs from all flights in Iceepeecee at the given angle (theta).
     * 
     * @param theta The angle (in radians) at which the photographs are taken.
     */
    public void photograph(double theta) {
        for (Flight flight : flights.values()) {
            String color = flight.getColor(); // Get the color of the flight
            flight.camera(color, theta); // Calls the camera method of each flight with the color and theta
        }
    }
    
    /**
     * Make all elements in Iceepeecee visible, including flights, islands, and photographs.
     */
    public void makeVisible() {
        // Make all flights visible
        for (Flight flight : flights.values()) {
            String color = flight.getColor();
            flight.makeFlightVisible(color);
        }

        // Make all islands visible
        for (Island island : islands.values()) {
            String color = island.getColor();
            island.makeIslandVisible(color);
        }
        
        // Make all photographs visible
        for (Flight flight : flights.values()) {
            List<Photograph> photographs = flight.getPhotographs();
            for (Photograph photograph : photographs) {
                photograph.makeVisible(); // Hace invisible cada fotografía asociada a un vuelo
            }
        }
    }

    /**
     * Make all elements in Iceepeecee invisible, including flights, islands, and photographs.
     */
    public void makeInvisible() {
        // Make all flights invisible
        for (Flight flight : flights.values()) {
            String color = flight.getColor();
            flight.makeFlightInvisible(color);
        }
        // Make all islands invisible
        for (Island island : islands.values()) {
            String color = island.getColor();
            island.makeIslandInvisible(color);
        }
        // Make all photographs invisible
        for (Flight flight : flights.values()) {
            List<Photograph> photographs = flight.getPhotographs();
            for (Photograph photograph : photographs) {
                photograph.makeInvisible(); // Hace invisible cada fotografía asociada a un vuelo
            }
        }
    }
    
    /**
     * Muestra la información de todas las islas almacenadas en Iceepeecee.
     */
    public void showAllIslands() {
        System.out.println("Islas almacenadas en Iceepeecee:");
        for (Island island : islands.values()) {
            String color = island.getColor();
            System.out.println("Color: " + color);
            System.out.println(island.locationIsland(color)); // Utiliza el método locationIsland para mostrar la ubicación
            System.out.println("------------------------");
        }
    }
    
    /**
     * Muestra la información de todos los vuelos almacenados en Iceepeecee.
     */
    public void showAllFlights() {
        System.out.println("Vuelos almacenadss en Iceepeecee:");
        for (Flight flight : flights.values()) {
            String color = flight.getColor();
            System.out.println("Color: " + color);
            System.out.println(flight.locationFlight(color)); // Utiliza el método locationIsland para mostrar la ubicación
            System.out.println("------------------------");
        }
    }

}
