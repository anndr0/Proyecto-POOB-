import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class IceepeeceeTest {
    private Iceepeecee iceepeecee;

    @Before
    public void setUp() {
        // Configurar un nuevo Iceepeecee antes de cada prueba
        iceepeecee = new Iceepeecee(800, 600);
    }

    @Test
    public void testAddIsland() {
        // Definir un arreglo de vértices para la isla
        int[][] islandVertices = {
            {100, 100},
            {200, 100},
            {200, 200},
            {100, 200}
        };

        // Agregar la isla al Iceepeecee
        iceepeecee.addIsland("blue", islandVertices);

        // Comprobar que la isla se haya agregado correctamente
        Island island = iceepeecee.getIsland("blue");
        assertNotNull(island);
        assertEquals("blue", island.getColor());
    }
}
